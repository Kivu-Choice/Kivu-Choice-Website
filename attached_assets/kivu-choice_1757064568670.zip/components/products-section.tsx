import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Fish, Sparkles, ShoppingCart, CheckCircle, Star, Users, Truck } from "lucide-react"

export function ProductsSection() {
  const products = [
    {
      id: "fresh-tilapia",
      category: "Fresh Fish",
      title: "Premium Fresh Tilapia",
      subtitle: "Lake Kivu's finest tilapia, farm-to-table fresh",
      description:
        "Our sustainably farmed tilapia from Lake Kivu delivers exceptional quality and taste. Raised in pristine conditions using advanced aquaculture practices, our fresh tilapia provides premium protein for restaurants, hotels, and families across Rwanda.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Harvest-scaled.jpg-2fqUVyXpxbciEToEUVc0ET1HmfcXvD.jpeg",
      features: [
        "Sustainably farmed in Lake Kivu",
        "No antibiotics or harmful chemicals",
        "Fresh daily delivery available",
        "Multiple sizes available (250g-2kg)",
        "Competitive wholesale pricing",
      ],
      benefits: [
        { icon: Fish, text: "Premium Lake Kivu tilapia" },
        { icon: CheckCircle, text: "Sustainably farmed" },
        { icon: Star, text: "Superior freshness guaranteed" },
      ],
      pricing: "Starting from 2,500 RWF/kg",
      cta: "Order Fresh Tilapia",
      popular: true,
    },
    {
      id: "processed-fish",
      category: "Processed Products",
      title: "Value-Added Fish Products",
      subtitle: "Convenient, ready-to-cook fish products",
      description:
        "Our processed fish products offer convenience without compromising quality. From filleted tilapia to smoked fish, we provide restaurant-ready products that save time while maintaining the exceptional taste of Lake Kivu tilapia.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC-Branch-1-Edited-scaled.jpg-EYnH5jdpx2D1KDVXACJq2AvB4g8TFG.jpeg",
      features: [
        "Professional filleting and processing",
        "Vacuum-sealed for freshness",
        "Custom cuts available",
        "Extended shelf life",
        "Food service packaging options",
      ],
      benefits: [
        { icon: Truck, text: "Ready-to-cook convenience" },
        { icon: Sparkles, text: "Professional processing" },
        { icon: Users, text: "Perfect for food service" },
      ],
      pricing: "3,200 RWF per kg (processed)",
      cta: "Order Processed Fish",
      popular: false,
    },
  ]

  const services = [
    {
      title: "Bulk Supply",
      description: "Large-scale supply for restaurants, hotels, and food service operations",
      icon: Fish,
    },
    {
      title: "Custom Processing",
      description: "Tailored processing services to meet your specific requirements",
      icon: Sparkles,
    },
    {
      title: "Distribution Network",
      description: "Reliable delivery across Rwanda with cold chain management",
      icon: Truck,
    },
  ]

  return (
    <section id="products" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-kivu-blue/10 text-kivu-blue px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <Fish className="h-4 w-4" />
            <span>Our Products</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-6">
            Premium Tilapia Products for <span className="text-kivu-green">Every Need</span>
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            From fresh whole tilapia for your restaurant to processed products for food service, we deliver Lake Kivu's
            finest fish with unmatched quality and reliability.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          {products.map((product) => (
            <Card
              key={product.id}
              className={`relative overflow-hidden border-2 transition-all duration-300 hover:shadow-xl ${
                product.popular ? "border-kivu-blue bg-kivu-blue/5" : "border-border hover:border-kivu-green/20"
              }`}
            >
              {product.popular && (
                <div className="absolute top-4 right-4 z-10">
                  <Badge className="bg-kivu-blue text-white font-body font-medium">Most Popular</Badge>
                </div>
              )}

              <div className="relative h-64 overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <Badge variant="secondary" className="font-body text-xs">
                    {product.category}
                  </Badge>
                </div>
              </div>

              <CardHeader className="pb-4">
                <CardTitle className="font-heading text-2xl font-bold text-foreground">{product.title}</CardTitle>
                <p className="font-body text-kivu-green font-medium">{product.subtitle}</p>
              </CardHeader>

              <CardContent className="space-y-6">
                <p className="font-body text-muted-foreground leading-relaxed">{product.description}</p>

                {/* Benefits */}
                <div className="space-y-3">
                  <h4 className="font-heading text-sm font-bold text-foreground uppercase tracking-wide">
                    Key Benefits
                  </h4>
                  <div className="grid gap-2">
                    {product.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-kivu-green/10">
                          <benefit.icon className="h-3 w-3 text-kivu-green" />
                        </div>
                        <span className="font-body text-sm text-muted-foreground">{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-3">
                  <h4 className="font-heading text-sm font-bold text-foreground uppercase tracking-wide">Features</h4>
                  <div className="grid gap-2">
                    {product.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-kivu-green flex-shrink-0" />
                        <span className="font-body text-sm text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing & CTA */}
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="font-heading text-2xl font-bold text-foreground">{product.pricing}</div>
                      <div className="font-body text-xs text-muted-foreground">Volume discounts available</div>
                    </div>
                  </div>
                  <Button
                    className={`w-full font-body font-semibold group ${
                      product.popular
                        ? "bg-kivu-blue hover:bg-kivu-blue/90 text-white"
                        : "bg-kivu-green hover:bg-kivu-green/90 text-white"
                    }`}
                  >
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    {product.cta}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Services Section */}
        <div className="bg-muted/20 rounded-2xl p-12">
          <div className="text-center mb-12">
            <h3 className="font-heading text-2xl font-bold text-foreground mb-4">Additional Services</h3>
            <p className="font-body text-muted-foreground max-w-2xl mx-auto">
              Beyond our core products, we offer comprehensive services to support your business and operational needs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-kivu-green/10 mx-auto mb-4">
                  <service.icon className="h-8 w-8 text-kivu-green" />
                </div>
                <h4 className="font-heading text-lg font-bold text-foreground mb-2">{service.title}</h4>
                <p className="font-body text-sm text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className="font-body font-semibold bg-transparent border-kivu-green text-kivu-green hover:bg-kivu-green hover:text-white"
            >
              Learn More About Our Services
            </Button>
          </div>
        </div>

        {/* Quality Assurance */}
        <div className="mt-20 text-center">
          <div className="inline-flex items-center space-x-2 bg-kivu-green/10 text-kivu-green px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <CheckCircle className="h-4 w-4" />
            <span>Quality Guaranteed</span>
          </div>
          <h3 className="font-heading text-2xl font-bold text-foreground mb-4">Rigorous Quality Standards</h3>
          <p className="font-body text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">
            Every fish undergoes strict quality control processes. Our facilities are certified and regularly inspected
            to ensure the highest standards of safety, freshness, and sustainability in aquaculture operations.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Badge variant="outline" className="font-body">
              ISO 22000 Certified
            </Badge>
            <Badge variant="outline" className="font-body">
              HACCP Compliant
            </Badge>
            <Badge variant="outline" className="font-body">
              Rwanda Standards Board Approved
            </Badge>
            <Badge variant="outline" className="font-body">
              Sustainably Farmed
            </Badge>
          </div>
        </div>
      </div>
    </section>
  )
}
