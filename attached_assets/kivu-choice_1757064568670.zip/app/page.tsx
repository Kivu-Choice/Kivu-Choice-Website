import { Header } from "@/components/header"
import { LandingHero } from "@/components/landing-hero"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <LandingHero />
      <Footer />
    </div>
  )
}
