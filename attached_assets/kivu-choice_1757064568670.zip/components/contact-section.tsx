import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Mail, Clock, Send, MessageSquare, Users, Building } from "lucide-react"

export function ContactSection() {
  const contactMethods = [
    {
      icon: Phone,
      title: "Call Us",
      details: ["+250 788 123 456", "+250 722 987 654"],
      description: "Mon-Fri 8AM-6PM, Sat 9AM-4PM",
      action: "Call Now",
    },
    {
      icon: Mail,
      title: "Email Us",
      details: ["info@kivuchoice.rw", "orders@kivuchoice.rw"],
      description: "We respond within 24 hours",
      action: "Send Email",
    },
    {
      icon: MapPin,
      title: "Visit Us",
      details: ["Kivu Choice Headquarters", "Kigali, Rwanda"],
      description: "KG 15 Ave, Kimisagara Sector",
      action: "Get Directions",
    },
    {
      icon: MessageSquare,
      title: "WhatsApp",
      details: ["+250 788 123 456"],
      description: "Quick responses via WhatsApp",
      action: "Chat Now",
    },
  ]

  const inquiryTypes = [
    { value: "general", label: "General Inquiry", icon: MessageSquare },
    { value: "products", label: "Product Information", icon: Building },
    { value: "partnership", label: "Partnership", icon: Users },
    { value: "bulk", label: "Bulk Orders", icon: Building },
  ]

  return (
    <section id="contact" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-accent/10 text-accent px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <MessageSquare className="h-4 w-4" />
            <span>Get in Touch</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-6">
            Let's Start a <span className="text-primary">Conversation</span>
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Whether you're interested in our products, want to partner with us, or have questions about our mission,
            we'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Methods */}
          <div className="lg:col-span-1 space-y-6">
            <div>
              <h3 className="font-heading text-xl font-bold text-foreground mb-6">How to Reach Us</h3>
              <div className="space-y-4">
                {contactMethods.map((method, index) => (
                  <Card key={index} className="border-0 bg-muted/20 hover:bg-muted/30 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 flex-shrink-0">
                          <method.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-body font-semibold text-foreground mb-1">{method.title}</h4>
                          {method.details.map((detail, idx) => (
                            <p key={idx} className="font-body text-sm text-muted-foreground">
                              {detail}
                            </p>
                          ))}
                          <p className="font-body text-xs text-muted-foreground mt-1">{method.description}</p>
                          <Button variant="link" className="h-auto p-0 font-body text-xs text-primary mt-2">
                            {method.action}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Business Hours */}
            <Card className="border-0 bg-primary/5">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 font-heading text-lg">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Business Hours</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Monday - Friday</span>
                  <span className="text-foreground font-medium">8:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Saturday</span>
                  <span className="text-foreground font-medium">9:00 AM - 4:00 PM</span>
                </div>
                <div className="flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Sunday</span>
                  <span className="text-foreground font-medium">Closed</span>
                </div>
                <div className="pt-2 border-t">
                  <Badge className="bg-accent/10 text-accent font-body text-xs">Emergency orders: 24/7 WhatsApp</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="border-0 bg-muted/10">
              <CardHeader>
                <CardTitle className="font-heading text-xl font-bold text-foreground">Send Us a Message</CardTitle>
                <p className="font-body text-muted-foreground text-sm">
                  Fill out the form below and we'll get back to you within 24 hours.
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Inquiry Type Selection */}
                <div>
                  <label className="font-body text-sm font-medium text-foreground mb-3 block">
                    What can we help you with?
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {inquiryTypes.map((type) => (
                      <label
                        key={type.value}
                        className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-muted/20 transition-colors"
                      >
                        <input type="radio" name="inquiryType" value={type.value} className="sr-only" />
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                          <type.icon className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-body text-sm text-foreground">{type.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Form Fields */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="font-body text-sm font-medium text-foreground mb-2 block">First Name</label>
                    <Input placeholder="Enter your first name" className="font-body" />
                  </div>
                  <div>
                    <label className="font-body text-sm font-medium text-foreground mb-2 block">Last Name</label>
                    <Input placeholder="Enter your last name" className="font-body" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="font-body text-sm font-medium text-foreground mb-2 block">Email</label>
                    <Input type="email" placeholder="your.email@example.com" className="font-body" />
                  </div>
                  <div>
                    <label className="font-body text-sm font-medium text-foreground mb-2 block">Phone</label>
                    <Input type="tel" placeholder="+250 xxx xxx xxx" className="font-body" />
                  </div>
                </div>

                <div>
                  <label className="font-body text-sm font-medium text-foreground mb-2 block">
                    Organization (Optional)
                  </label>
                  <Input placeholder="Your company or organization" className="font-body" />
                </div>

                <div>
                  <label className="font-body text-sm font-medium text-foreground mb-2 block">Message</label>
                  <Textarea
                    placeholder="Tell us more about your inquiry..."
                    className="font-body min-h-[120px] resize-none"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="newsletter" className="rounded border-border" />
                  <label htmlFor="newsletter" className="font-body text-sm text-muted-foreground">
                    Subscribe to our newsletter for updates on our impact and new products
                  </label>
                </div>

                <Button
                  size="lg"
                  className="w-full font-body font-semibold bg-accent hover:bg-accent/90 text-accent-foreground group"
                >
                  <Send className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-20">
          <Card className="border-0 bg-muted/10 overflow-hidden">
            <div className="grid lg:grid-cols-3">
              <div className="lg:col-span-2 h-64 lg:h-80 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-12 w-12 text-primary mx-auto mb-4" />
                  <p className="font-body text-muted-foreground">Interactive map coming soon</p>
                  <Button variant="outline" className="mt-4 font-body bg-transparent">
                    Get Directions
                  </Button>
                </div>
              </div>
              <div className="p-8 bg-background/80 backdrop-blur-sm">
                <h3 className="font-heading text-xl font-bold text-foreground mb-4">Visit Our Facility</h3>
                <div className="space-y-3 font-body text-sm">
                  <div>
                    <p className="text-muted-foreground">Address:</p>
                    <p className="text-foreground font-medium">KG 15 Ave, Kimisagara Sector</p>
                    <p className="text-foreground font-medium">Kigali, Rwanda</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Coordinates:</p>
                    <p className="text-foreground font-medium">-1.9441, 30.0619</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Parking:</p>
                    <p className="text-foreground font-medium">Free on-site parking available</p>
                  </div>
                </div>
                <Button className="w-full mt-6 font-body font-semibold bg-primary hover:bg-primary/90 text-primary-foreground">
                  Schedule a Visit
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
