import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Fish, Factory, Truck, TrendingUp } from "lucide-react"

export function AboutSection() {
  const operations = [
    {
      icon: Fish,
      title: "The Hatchery",
      description: "One of Africa's largest hatcheries with 5+ million fingerling production capacity monthly.",
    },
    {
      icon: Factory,
      title: "Production Farm",
      description: "Cage-based farming operations on Lake Kivu with sustainable and responsible practices.",
    },
    {
      icon: Truck,
      title: "Sales & Logistics",
      description: "Daily harvest and nationwide distribution through our branded outlets across Rwanda.",
    },
  ]

  const milestones = [
    { year: "2021", title: "Founded", description: "Company founded in September 2021" },
    { year: "2022", title: "Operations", description: "First cage stocked on Lake Kivu" },
    { year: "2023", title: "Growth", description: "Raised $35M Series B funding" },
    { year: "2024", title: "Scale", description: "Reached 5000 tons annualized production" },
  ]

  return (
    <section id="about" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-kivu-green/10 text-kivu-green px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <Fish className="h-4 w-4" />
            <span>Who We Are</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-6">
            Rwanda's <span className="text-kivu-green">Largest Protein Producer</span>
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Kivu Choice is a vertically integrated aquaculture company with associated feed mill, hatchery, cage
            production, distribution, and sales outlets. Founded in late 2021, we are now Africa's fastest growing fish
            farm.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Story Content */}
          <div className="space-y-6">
            <h3 className="font-heading text-2xl font-bold text-foreground">Democratizing Access to Animal Protein</h3>
            <div className="space-y-4 font-body text-muted-foreground leading-relaxed">
              <p>
                Our mission is to democratize access to animal protein by radically increasing affordability and supply
                across the region. We do this through continuous innovation and careful execution across every step of
                the value chain.
              </p>
              <p>
                From our state-of-the-art hatchery producing over 5 million fingerlings monthly to our cage-based
                farming operations on Lake Kivu, we maintain industry-leading performance metrics through data-driven
                farming practices.
              </p>
              <p>
                By owning and operating our nationwide branches and distribution centers, we ensure the best quality
                product at the lowest price, with the greatest level of accessibility to our customers across Rwanda.
              </p>
            </div>
            <Button className="font-body font-semibold bg-kivu-green hover:bg-kivu-green/90 text-white">
              Find Our Branches
            </Button>
          </div>

          {/* Visual Content */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Feeding-1-scaled.jpg-YuqghBs32jX4zzYYabPpcW9Hkafe8T.jpeg"
                  alt="Kivu Choice feeding operations on Lake Kivu"
                  className="w-full h-48 object-cover rounded-lg shadow-lg"
                />
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC-Branch-1-Edited-scaled.jpg-EYnH5jdpx2D1KDVXACJq2AvB4g8TFG.jpeg"
                  alt="Kivu Choice processing facility interior"
                  className="w-full h-36 object-cover rounded-lg shadow-lg"
                />
              </div>
              <div className="space-y-4 pt-8">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Harvest-scaled.jpg-2fqUVyXpxbciEToEUVc0ET1HmfcXvD.jpeg"
                  alt="Fresh tilapia harvest at Kivu Choice"
                  className="w-full h-36 object-cover rounded-lg shadow-lg"
                />
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FeedersTeam-1024x683.jpg-cA7vQ4FKAIRI6BVf3tqUKNAcrdBx5s.jpeg"
                  alt="Kivu Choice team operations on Lake Kivu"
                  className="w-full h-48 object-cover rounded-lg shadow-lg"
                />
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 bg-background border rounded-lg p-4 shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-kivu-green/10">
                  <TrendingUp className="h-5 w-5 text-kivu-green" />
                </div>
                <div>
                  <div className="font-heading text-lg font-bold text-foreground">Fastest Growing</div>
                  <div className="font-body text-sm text-muted-foreground">Fish Farm in Africa</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-20">
          <h3 className="font-heading text-2xl font-bold text-foreground text-center mb-12">What We Do</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {operations.map((operation, index) => (
              <Card key={index} className="border-0 bg-muted/20 hover:bg-muted/30 transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-kivu-green/10 mx-auto mb-4">
                    <operation.icon className="h-6 w-6 text-kivu-green" />
                  </div>
                  <h4 className="font-heading text-lg font-bold text-foreground mb-2">{operation.title}</h4>
                  <p className="font-body text-muted-foreground text-sm leading-relaxed">{operation.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-heading text-2xl font-bold text-foreground text-center mb-12">Our Growth</h3>
          <div className="grid md:grid-cols-4 gap-8">
            {milestones.map((milestone, index) => (
              <div key={index} className="text-center">
                <div className="relative">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-kivu-green text-white mx-auto mb-4">
                    <span className="font-heading text-lg font-bold">{milestone.year}</span>
                  </div>
                  {index < milestones.length - 1 && (
                    <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-border -translate-y-0.5" />
                  )}
                </div>
                <h4 className="font-heading text-lg font-bold text-foreground mb-2">{milestone.title}</h4>
                <p className="font-body text-sm text-muted-foreground leading-relaxed">{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
