import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Fish, TrendingUp, MapPin, Star, Quote, ArrowRight } from "lucide-react"

export function ImpactSection() {
  const impactStats = [
    {
      icon: Users,
      number: "500+",
      label: "Jobs Created",
      description: "Across our operations and supply chain",
      color: "text-kivu-green",
      bgColor: "bg-kivu-green/10",
    },
    {
      icon: Fish,
      number: "400MT",
      label: "Monthly Production",
      description: "Fresh tilapia from Lake Kivu",
      color: "text-kivu-blue",
      bgColor: "bg-kivu-blue/10",
    },
    {
      icon: TrendingUp,
      number: "5M+",
      label: "Fingerlings Annually",
      description: "Supporting aquaculture growth",
      color: "text-kivu-green",
      bgColor: "bg-kivu-green/10",
    },
    {
      icon: MapPin,
      number: "15+",
      label: "Distribution Points",
      description: "Across Rwanda and region",
      color: "text-kivu-blue",
      bgColor: "bg-kivu-blue/10",
    },
  ]

  const testimonials = [
    {
      name: "Jean Claude Nzeyimana",
      role: "Restaurant Owner, Kigali",
      image: "/placeholder.svg?height=80&width=80&text=Jean",
      quote:
        "Kivu Choice has been our reliable fish supplier for 3 years. Their tilapia quality is exceptional and consistent. Our customers always compliment the freshness and taste.",
      rating: 5,
    },
    {
      name: "Sarah Mukamana",
      role: "Hotel Manager, Musanze",
      image: "/placeholder.svg?height=80&width=80&text=Sarah",
      quote:
        "The delivery service is outstanding. Fresh fish arrives on time every morning, and the quality control is impressive. Our guests love the Lake Kivu tilapia dishes.",
      rating: 5,
    },
    {
      name: "Emmanuel Habimana",
      role: "Fish Distributor, Huye",
      image: "/placeholder.svg?height=80&width=80&text=Emmanuel",
      quote:
        "Working with Kivu Choice has transformed my business. Their consistent supply and competitive pricing help me serve more customers across the southern province.",
      rating: 5,
    },
  ]

  const partnerships = [
    {
      name: "Rwanda Development Board",
      description: "Supporting aquaculture sector growth",
      logo: "/placeholder.svg?height=60&width=120&text=RDB+Logo",
    },
    {
      name: "Ministry of Agriculture",
      description: "Sustainable farming practices partnership",
      logo: "/placeholder.svg?height=60&width=120&text=MINAGRI+Logo",
    },
    {
      name: "Hotel Rwanda",
      description: "Premium fish supply partnership",
      logo: "/placeholder.svg?height=60&width=120&text=Hotel+Logo",
    },
    {
      name: "Local Cooperatives",
      description: "Community-based distribution network",
      logo: "/placeholder.svg?height=60&width=120&text=Coop+Logo",
    },
  ]

  return (
    <section id="impact" className="py-20 lg:py-32 bg-gradient-to-br from-background via-kivu-green/5 to-kivu-blue/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-kivu-green/10 text-kivu-green px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <Fish className="h-4 w-4" />
            <span>Our Impact</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-6">
            Driving Rwanda's <span className="text-kivu-blue">Aquaculture Growth</span>
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            See how we're transforming Rwanda's protein sector through sustainable aquaculture, job creation, and
            reliable fish supply across the region.
          </p>
        </div>

        {/* Impact Statistics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {impactStats.map((stat, index) => (
            <Card
              key={index}
              className="border-0 bg-background/60 backdrop-blur-sm hover:bg-background/80 transition-all duration-300 group"
            >
              <CardContent className="p-6 text-center">
                <div
                  className={`flex h-14 w-14 items-center justify-center rounded-lg ${stat.bgColor} group-hover:scale-110 transition-transform mx-auto mb-4`}
                >
                  <stat.icon className={`h-7 w-7 ${stat.color}`} />
                </div>
                <div className={`font-heading text-3xl font-black ${stat.color} mb-1`}>{stat.number}</div>
                <div className="font-body text-sm font-semibold text-foreground mb-2">{stat.label}</div>
                <p className="font-body text-xs text-muted-foreground">{stat.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Success Story Highlight */}
        <div className="bg-background/80 backdrop-blur-sm rounded-2xl p-12 mb-20 border">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-kivu-blue/10 text-kivu-blue font-body mb-4">Success Story</Badge>
              <h3 className="font-heading text-2xl font-bold text-foreground mb-4">
                From Startup to Rwanda's Largest Fish Farm
              </h3>
              <p className="font-body text-muted-foreground leading-relaxed mb-6">
                In just 4 years, we've grown from a small operation to Rwanda's largest protein producer. Our vertically
                integrated approach from hatchery to distribution has created a sustainable aquaculture ecosystem that
                supports hundreds of families.
              </p>
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="font-heading text-2xl font-bold text-kivu-green">400MT</div>
                  <div className="font-body text-sm text-muted-foreground">Monthly Production</div>
                </div>
                <div>
                  <div className="font-heading text-2xl font-bold text-kivu-blue">500+</div>
                  <div className="font-body text-sm text-muted-foreground">Jobs Created</div>
                </div>
              </div>
              <Button className="font-body font-semibold bg-kivu-green hover:bg-kivu-green/90 text-white">
                Learn About Our Journey
              </Button>
            </div>
            <div className="relative">
              <img
                src="/placeholder.svg?height=400&width=500&text=Fish+Farm+Operations"
                alt="Kivu Choice fish farm operations"
                className="w-full h-80 object-cover rounded-lg"
              />
              <div className="absolute top-4 right-4 bg-background/95 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                <div className="font-body text-xs text-muted-foreground">Growth Since 2021</div>
                <div className="font-heading text-lg font-bold text-kivu-green">+2000%</div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h3 className="font-heading text-2xl font-bold text-foreground mb-4">What Our Customers Say</h3>
            <p className="font-body text-muted-foreground max-w-2xl mx-auto">
              Hear from restaurants, hotels, and distributors who trust Kivu Choice for their fish supply needs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="border-0 bg-background/60 backdrop-blur-sm hover:bg-background/80 transition-all duration-300"
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-kivu-blue fill-current" />
                    ))}
                  </div>
                  <Quote className="h-8 w-8 text-kivu-green/20 mb-4" />
                  <p className="font-body text-muted-foreground leading-relaxed mb-6 italic">"{testimonial.quote}"</p>
                  <div className="flex items-center space-x-3">
                    <img
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-body font-semibold text-foreground">{testimonial.name}</div>
                      <div className="font-body text-sm text-muted-foreground">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Partnerships */}
        <div className="bg-muted/20 rounded-2xl p-12">
          <div className="text-center mb-12">
            <h3 className="font-heading text-2xl font-bold text-foreground mb-4">Strategic Partners</h3>
            <p className="font-body text-muted-foreground max-w-2xl mx-auto">
              We collaborate with government agencies, hotels, and cooperatives to strengthen Rwanda's aquaculture
              sector.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            {partnerships.map((partner, index) => (
              <div key={index} className="text-center">
                <div className="bg-background rounded-lg p-6 mb-4 hover:shadow-md transition-shadow">
                  <img
                    src={partner.logo || "/placeholder.svg"}
                    alt={`${partner.name} logo`}
                    className="h-12 mx-auto mb-3 opacity-70 hover:opacity-100 transition-opacity"
                  />
                  <h4 className="font-body font-semibold text-foreground text-sm mb-1">{partner.name}</h4>
                  <p className="font-body text-xs text-muted-foreground">{partner.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="outline"
              className="font-body font-semibold bg-transparent border-kivu-green text-kivu-green hover:bg-kivu-green hover:text-white group"
            >
              Become a Partner
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-20">
          <h3 className="font-heading text-2xl font-bold text-foreground mb-4">Ready to Partner with Us?</h3>
          <p className="font-body text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join Rwanda's leading fish farm and be part of the aquaculture revolution. Whether you're a restaurant,
            distributor, or investor, we have solutions for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="font-body font-semibold bg-kivu-blue hover:bg-kivu-blue/90 text-white group">
              Start Partnership
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="font-body font-semibold bg-transparent border-kivu-green text-kivu-green hover:bg-kivu-green hover:text-white"
            >
              Download Company Profile
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
