import { Header } from "@/components/header"
import { ProductsSection } from "@/components/products-section"
import { ShopSection } from "@/components/shop-section"
import { Footer } from "@/components/footer"

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-20">
        <ProductsSection />
        <ShopSection />
      </div>
      <Footer />
    </div>
  )
}
