import { Button } from "@/components/ui/button"
import { ArrowRight, Fish, Award, Users } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export function LandingHero() {
  return (
    <section className="min-h-screen bg-white relative overflow-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 right-20 w-64 h-64 bg-kivu-green/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-kivu-blue/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 pt-16">
        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-20 items-center max-w-7xl mx-auto">
          {/* Left Content - Increased spacing and improved hierarchy */}
          <div className="text-center lg:text-left space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-kivu-green/10 rounded-full text-kivu-green font-semibold text-sm">
              <Award className="w-4 h-4 mr-2" />
              Africa's Fastest Growing Fish Farm
            </div>

            {/* Logo */}
            <div>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Fish-and-text_Horizontal_Color-2048x823-KNTahs43kDdKqRk9a0GPldS7krlaEO.png"
                alt="Kivu Choice - Fresh Rwandan Tilapia"
                width={400}
                height={160}
                className="h-20 w-auto mx-auto lg:mx-0"
                priority
              />
            </div>

            {/* Massive Headline - Made even larger and more dominant like Lattice */}
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold text-gray-900 leading-[0.85] tracking-tighter">
              Fresh Rwandan
              <br />
              <span className="text-kivu-blue">Tilapia</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium">
              Rwanda's largest protein producer delivering premium tilapia from Lake Kivu. Vertically integrated
              operations from hatchery to your table.
            </p>

            {/* CTA Buttons - Made more prominent with better styling */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start items-center pt-4">
              <Link href="/products">
                <Button
                  size="lg"
                  className="bg-kivu-green hover:bg-kivu-green/90 text-white px-10 py-7 text-xl font-bold shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 rounded-xl"
                >
                  <Fish className="w-6 h-6 mr-3" />
                  View Our Products
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Button>
              </Link>
              <Link href="/about">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 px-10 py-7 text-xl font-bold bg-transparent rounded-xl transition-all duration-300"
                >
                  <Users className="w-6 h-6 mr-3" />
                  Our Story
                </Button>
              </Link>
            </div>
          </div>

          {/* Right Content - Clean Hero Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Providence_Holding_Fish-scaled.jpg-MB8sHqAKFFovRV5rOkbwqX4LDzY887.jpeg"
                alt="Kivu Choice team member holding fresh tilapia at Lake Kivu fish farm"
                width={600}
                height={600}
                className="w-full h-[500px] lg:h-[600px] object-cover"
                priority
              />
            </div>
          </div>
        </div>

        {/* Stats Section - Improved spacing and visual impact */}
        <div className="mt-32 mb-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center bg-white rounded-2xl p-10 shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-300">
              <div className="text-5xl md:text-6xl font-bold text-kivu-green mb-3">400MT</div>
              <div className="text-gray-600 font-semibold text-lg">Monthly Harvest</div>
            </div>
            <div className="text-center bg-white rounded-2xl p-10 shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-300">
              <div className="text-5xl md:text-6xl font-bold text-kivu-blue mb-3">5M+</div>
              <div className="text-gray-600 font-semibold text-lg">Fingerlings Annually</div>
            </div>
            <div className="text-center bg-white rounded-2xl p-10 shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-300">
              <div className="text-5xl md:text-6xl font-bold text-kivu-green mb-3">500+</div>
              <div className="text-gray-600 font-semibold text-lg">Jobs Created</div>
            </div>
          </div>
        </div>

        {/* Quick Links - Enhanced hover effects and spacing */}
        <div className="pb-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <Link href="/about" className="group">
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-kivu-green/30 hover:-translate-y-1">
                <div className="text-kivu-green font-bold text-xl mb-2">Learn About Us</div>
                <div className="text-gray-500 text-sm font-medium">Company & Mission</div>
              </div>
            </Link>
            <Link href="/team" className="group">
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-kivu-blue/30 hover:-translate-y-1">
                <div className="text-kivu-blue font-bold text-xl mb-2">Meet Our Team</div>
                <div className="text-gray-500 text-sm font-medium">Leadership & Experts</div>
              </div>
            </Link>
            <Link href="/media" className="group">
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-kivu-green/30 hover:-translate-y-1">
                <div className="text-kivu-green font-bold text-xl mb-2">Latest News</div>
                <div className="text-gray-500 text-sm font-medium">Media & Updates</div>
              </div>
            </Link>
            <Link href="/contact" className="group">
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-kivu-blue/30 hover:-translate-y-1">
                <div className="text-kivu-blue font-bold text-xl mb-2">Get In Touch</div>
                <div className="text-gray-500 text-sm font-medium">Contact & Orders</div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
