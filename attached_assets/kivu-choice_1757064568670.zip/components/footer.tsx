import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, ArrowRight } from "lucide-react"

export function Footer() {
  const footerLinks = {
    company: [
      { name: "About Us", href: "/about" },
      { name: "Our Operations", href: "/about" },
      { name: "Sustainability", href: "/about" },
      { name: "Careers", href: "/careers" },
      { name: "Press", href: "/media" },
    ],
    products: [
      { name: "Fresh Tilapia", href: "/products" },
      { name: "Bulk Orders", href: "/products" },
      { name: "Quality Standards", href: "/products" },
      { name: "Distribution", href: "/contact" },
      { name: "Pricing", href: "/products" },
    ],
    support: [
      { name: "Contact Us", href: "/contact" },
      { name: "FAQ", href: "/contact" },
      { name: "Shipping Info", href: "/contact" },
      { name: "Returns", href: "/contact" },
      { name: "Support Center", href: "/contact" },
    ],
    legal: [
      { name: "Privacy Policy", href: "/privacy" },
      { name: "Terms of Service", href: "/terms" },
      { name: "Cookie Policy", href: "/cookies" },
      { name: "Compliance", href: "/compliance" },
    ],
  }

  const socialLinks = [
    { name: "Facebook", icon: Facebook, href: "https://facebook.com/kivuchoice" },
    { name: "Twitter", icon: Twitter, href: "https://twitter.com/kivuchoice" },
    { name: "Instagram", icon: Instagram, href: "https://instagram.com/kivuchoice" },
    { name: "LinkedIn", icon: Linkedin, href: "https://linkedin.com/company/kivuchoice" },
  ]

  return (
    <footer className="bg-foreground text-background">
      {/* Newsletter Section */}
      <div className="border-b border-background/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="font-heading text-2xl font-bold mb-2">Stay Updated on Our Operations</h3>
              <p className="font-body text-background/70">
                Get monthly updates on our harvest, new products, and latest developments from Rwanda's largest fish
                farm.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Input
                type="email"
                placeholder="Enter your email address"
                className="font-body bg-background/10 border-background/20 text-background placeholder:text-background/50"
              />
              <Button className="font-body font-semibold bg-kivu-blue hover:bg-kivu-blue/90 text-white group">
                Subscribe
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Fish-and-text_Horizontal_Color-2048x823-KNTahs43kDdKqRk9a0GPldS7krlaEO.png"
                alt="Kivu Choice - Fresh Rwandan Tilapia"
                className="h-16 w-auto"
              />
            </div>
            <p className="font-body text-background/70 leading-relaxed mb-6 max-w-md">
              Rwanda's largest protein producer and fastest growing fish farm. Vertically integrated aquaculture
              operations from hatchery to nationwide distribution of premium fresh tilapia.
            </p>
            <div className="space-y-2 font-body text-sm">
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-kivu-green" />
                <span className="text-background/70">Gatenga Branch, Kigali, Rwanda</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-kivu-green" />
                <span className="text-background/70">+250 798 583 136</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-kivu-green" />
                <span className="text-background/70">info@kivuchoice.rw</span>
              </div>
            </div>
          </div>

          {/* Footer Links */}
          <div>
            <h4 className="font-heading text-lg font-bold mb-4 text-kivu-green">Company</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-background/70 hover:text-kivu-blue transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading text-lg font-bold mb-4 text-kivu-blue">Products</h4>
            <ul className="space-y-2">
              {footerLinks.products.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-background/70 hover:text-kivu-green transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading text-lg font-bold mb-4 text-kivu-green">Support</h4>
            <ul className="space-y-2 mb-6">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-background/70 hover:text-kivu-blue transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>

            {/* Social Links */}
            <div>
              <h5 className="font-body text-sm font-semibold mb-3 text-kivu-blue">Follow Us</h5>
              <div className="flex space-x-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    className="flex h-8 w-8 items-center justify-center rounded-lg bg-kivu-green/20 hover:bg-kivu-blue/20 transition-colors"
                    aria-label={social.name}
                  >
                    <social.icon className="h-4 w-4 text-background/70" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-background/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="font-body text-sm text-background/70">
              © 2024 Kivu Choice. All rights reserved. | Registered in Rwanda: RDB/123456789
            </div>
            <div className="flex space-x-6">
              {footerLinks.legal.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="font-body text-sm text-background/70 hover:text-kivu-green transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
