"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { ShoppingCart, Star, CheckCircle } from "lucide-react"

interface ProductCardProps {
  id: string
  name: string
  category: string
  price: number
  unit: string
  image: string
  description: string
  features: string[]
  popular?: boolean
  inStock?: boolean
}

export function ProductCard({
  id,
  name,
  category,
  price,
  unit,
  image,
  description,
  features,
  popular = false,
  inStock = true,
}: ProductCardProps) {
  const { dispatch } = useCart()

  const addToCart = () => {
    dispatch({
      type: "ADD_ITEM",
      payload: {
        id,
        name,
        price,
        image,
        category,
        unit,
      },
    })
  }

  return (
    <Card
      className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
        popular ? "border-accent bg-accent/5" : "border-border hover:border-primary/20"
      }`}
    >
      {popular && (
        <div className="absolute top-4 right-4 z-10">
          <Badge className="bg-accent text-accent-foreground font-body font-medium">
            <Star className="h-3 w-3 mr-1" />
            Popular
          </Badge>
        </div>
      )}

      <div className="relative h-48 overflow-hidden">
        <img src={image || "/placeholder.svg"} alt={name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <div className="absolute bottom-4 left-4">
          <Badge variant="secondary" className="font-body text-xs">
            {category}
          </Badge>
        </div>
      </div>

      <CardHeader className="pb-3">
        <CardTitle className="font-heading text-lg font-bold text-foreground">{name}</CardTitle>
        <div className="flex items-center justify-between">
          <div className="font-heading text-xl font-bold text-primary">{price.toLocaleString()} RWF</div>
          <div className="font-body text-sm text-muted-foreground">per {unit}</div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="font-body text-sm text-muted-foreground leading-relaxed">{description}</p>

        <div className="space-y-2">
          <h4 className="font-body text-xs font-semibold text-foreground uppercase tracking-wide">Key Features</h4>
          <div className="space-y-1">
            {features.slice(0, 3).map((feature, index) => (
              <div key={index} className="flex items-center space-x-2">
                <CheckCircle className="h-3 w-3 text-primary flex-shrink-0" />
                <span className="font-body text-xs text-muted-foreground">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className={`h-2 w-2 rounded-full ${inStock ? "bg-green-500" : "bg-red-500"}`} />
              <span className="font-body text-xs text-muted-foreground">{inStock ? "In Stock" : "Out of Stock"}</span>
            </div>
          </div>
          <Button
            className={`w-full font-body font-semibold group ${
              popular
                ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                : "bg-primary hover:bg-primary/90 text-primary-foreground"
            }`}
            onClick={addToCart}
            disabled={!inStock}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Add to Cart
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
