import { ProductCard } from "@/components/product-card"
import { ShoppingCart } from "lucide-react"

export function ShopSection() {
  const products = [
    {
      id: "fresh-tilapia",
      name: "Fresh Tilapia",
      category: "Fresh Fish",
      price: 2500,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=400&text=Fresh+Tilapia",
      description:
        "Premium fresh tilapia, sustainably farmed in Lake Kivu. Perfect for family meals with exceptional taste and quality.",
      features: [
        "Sustainably farmed in Lake Kivu",
        "No antibiotics or chemicals",
        "Fresh daily delivery",
        "High-quality protein source",
        "Competitive wholesale pricing",
      ],
      popular: false,
      inStock: true,
    },
    {
      id: "nutripowder-plus",
      name: "NutriPowder Plus",
      category: "Fish Powder",
      price: 1200,
      unit: "250g",
      image: "/placeholder.svg?height=300&width=400&text=NutriPowder+Plus",
      description:
        "Revolutionary fish powder designed to prevent childhood stunting. Rich in essential nutrients and easy to use.",
      features: [
        "Prevents childhood stunting",
        "95% protein content",
        "Essential amino acids",
        "Fortified with vitamins",
        "Easy to mix with foods",
      ],
      popular: true,
      inStock: true,
    },
    {
      id: "fresh-catfish",
      name: "Fresh Catfish",
      category: "Fresh Fish",
      price: 3000,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=400&text=Fresh+Catfish",
      description:
        "Premium catfish with rich flavor and tender texture. Ideal for traditional Rwandan dishes and family gatherings.",
      features: [
        "Rich flavor profile",
        "Tender texture",
        "Sustainably sourced",
        "Perfect for local dishes",
        "Fresh daily supply",
      ],
      popular: false,
      inStock: true,
    },
    {
      id: "family-nutrition-pack",
      name: "Family Nutrition Pack",
      category: "Bundle",
      price: 4500,
      unit: "pack",
      image: "/placeholder.svg?height=300&width=400&text=Family+Pack",
      description:
        "Complete nutrition solution combining fresh fish and NutriPowder Plus. Perfect for families committed to healthy eating.",
      features: [
        "2kg fresh fish included",
        "500g NutriPowder Plus",
        "Family meal planning guide",
        "Nutrition consultation",
        "Best value package",
      ],
      popular: false,
      inStock: true,
    },
  ]

  return (
    <section className="py-20 lg:py-32 bg-muted/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <ShoppingCart className="h-4 w-4" />
            <span>Shop Now</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-6">
            Order <span className="text-accent">Fresh & Nutritious</span> Products
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Browse our selection of premium fresh fish and innovative nutrition products. All items are sustainably
            sourced and delivered fresh to your door.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {products.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>

        {/* Shipping Info */}
        <div className="bg-background rounded-2xl p-8 border">
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="font-heading text-lg font-bold text-foreground mb-2">Free Delivery</div>
              <p className="font-body text-sm text-muted-foreground">On orders over 5,000 RWF within Kigali</p>
            </div>
            <div>
              <div className="font-heading text-lg font-bold text-foreground mb-2">Fresh Guarantee</div>
              <p className="font-body text-sm text-muted-foreground">All products delivered within 24 hours</p>
            </div>
            <div>
              <div className="font-heading text-lg font-bold text-foreground mb-2">Quality Assured</div>
              <p className="font-body text-sm text-muted-foreground">ISO certified and health approved</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
