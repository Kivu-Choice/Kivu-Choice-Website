import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Calendar, TrendingUp } from "lucide-react"

const mediaArticles = [
  {
    title: "Kivu Choice revolutionalizing Africa's aquaculture industry through technology",
    excerpt:
      "The East African aquaculture group consisting of Kivu Choice Rwanda is leading innovation in sustainable fish farming across the continent.",
    category: "Technology",
    date: "2024",
    featured: true,
  },
  {
    title: "Kivu Choice: Rwanda-based firm is Africa's fastest-growing fish farm",
    excerpt:
      "From startup to market leader in just 3 years, Kivu Choice has become the largest protein producer in Rwanda.",
    category: "Growth",
    date: "2024",
    featured: true,
  },
  {
    title: "Kivu Choice, Victory Farms raise $35m for expansion in Rwanda, East Africa",
    excerpt: "The largest funding round in African aquaculture history will accelerate expansion across the region.",
    category: "Funding",
    date: "April 2023",
    featured: true,
  },
  {
    title: "Kenya's Victory Farms nets $5m as it edges towards precision fish farming",
    excerpt: "Sister company Victory Farms continues to innovate in precision aquaculture technology.",
    category: "Innovation",
    date: "May 2022",
    featured: false,
  },
  {
    title: "Impact investor DOB Equity, invests in East African fish farm, Victory Farms",
    excerpt: "Dutch family office recognizes the potential of sustainable aquaculture in East Africa.",
    category: "Investment",
    date: "November 2020",
    featured: false,
  },
  {
    title: "Open Roads' bridge loans aid social enterprises battered by Covid-19",
    excerpt: "COVID-19 provided an opening for Kenya's fish-farming industry to demonstrate resilience.",
    category: "Impact",
    date: "July 2020",
    featured: false,
  },
]

export default function MediaSection() {
  const featuredArticles = mediaArticles.filter((article) => article.featured)
  const otherArticles = mediaArticles.filter((article) => !article.featured)

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-kivu-blue/10 text-kivu-blue px-4 py-2 rounded-full text-sm font-body font-medium mb-4">
            <TrendingUp className="w-4 h-4" />
            In The News
          </div>
          <h2 className="font-heading text-4xl md:text-5xl font-black text-foreground mb-6">
            Media <span className="text-kivu-blue">&</span> Recognition
          </h2>
          <p className="font-body text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            From industry publications to major funding announcements, see how Kivu Choice is making waves in African
            aquaculture and sustainable protein production.
          </p>
        </div>

        {/* Featured Articles */}
        <div className="mb-16">
          <h3 className="font-heading text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
            <div className="w-1 h-8 bg-kivu-green rounded-full"></div>
            Featured Coverage
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredArticles.map((article, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-0 bg-background/80 backdrop-blur-sm hover:-translate-y-1"
              >
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-4">
                    <Badge
                      variant="outline"
                      className={`px-3 py-1 font-body ${
                        article.category === "Technology"
                          ? "bg-kivu-green/10 text-kivu-green border-kivu-green/20"
                          : article.category === "Growth"
                            ? "bg-kivu-blue/10 text-kivu-blue border-kivu-blue/20"
                            : "bg-orange-50 text-orange-700 border-orange-200"
                      }`}
                    >
                      {article.category}
                    </Badge>
                    <div className="flex items-center text-sm text-muted-foreground font-body">
                      <Calendar className="w-4 h-4 mr-1" />
                      {article.date}
                    </div>
                  </div>

                  <h4 className="font-heading text-xl font-bold text-foreground mb-4 group-hover:text-kivu-green transition-colors leading-tight">
                    {article.title}
                  </h4>

                  <p className="font-body text-muted-foreground mb-6 leading-relaxed">{article.excerpt}</p>

                  <Button
                    variant="outline"
                    className="group-hover:bg-kivu-green/10 group-hover:border-kivu-green/20 group-hover:text-kivu-green transition-colors bg-transparent font-body"
                  >
                    Read More
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Other Articles */}
        <div>
          <h3 className="font-heading text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
            <div className="w-1 h-8 bg-kivu-blue rounded-full"></div>
            Additional Coverage
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {otherArticles.map((article, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-all duration-300 border border-border hover:border-kivu-blue/20"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <Badge variant="secondary" className="text-xs font-body">
                      {article.category}
                    </Badge>
                    <span className="text-sm text-muted-foreground font-body">{article.date}</span>
                  </div>

                  <h4 className="font-heading text-lg font-semibold text-foreground mb-3 group-hover:text-kivu-blue transition-colors">
                    {article.title}
                  </h4>

                  <p className="font-body text-muted-foreground text-sm mb-4 leading-relaxed">{article.excerpt}</p>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-kivu-blue hover:text-kivu-blue/80 hover:bg-kivu-blue/10 p-0 font-body"
                  >
                    Read More <ExternalLink className="w-3 h-3 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-kivu-green to-kivu-blue rounded-2xl p-8 text-white">
            <h3 className="font-heading text-2xl font-bold mb-4">Stay Updated</h3>
            <p className="font-body text-white/90 mb-6 max-w-2xl mx-auto">
              Follow our journey as we continue to revolutionize aquaculture in Africa. Get the latest news, updates,
              and insights from Kivu Choice.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="secondary" className="bg-white text-kivu-green hover:bg-white/90 font-body">
                Subscribe to Updates
              </Button>
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-kivu-green bg-transparent font-body"
              >
                Media Kit
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
