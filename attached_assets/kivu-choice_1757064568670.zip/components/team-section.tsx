import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const teamMembers = [
  {
    name: "Kamran Ahmad",
    role: "Founder & CEO",
    education: "Stanford MBA, Oxford, Imperial College London",
    description:
      "Founded Kivu Choice after being inspired by Rwanda's potential in aquaculture. Previously at Victory Farms, East Africa's largest fish farm.",
    expertise: ["Strategy", "Leadership", "Aquaculture"],
  },
  {
    name: "Emmanuel Bahizi",
    role: "Chief Financial Officer",
    education: "Harvard Masters, University of Pennsylvania",
    description:
      "Former Corporate Banking Manager at Bank of Kigali. Oversees Finance, HR, and Procurement with focus on scalable business building.",
    expertise: ["Finance", "Banking", "Operations"],
  },
  {
    name: "Benjamin Bizima",
    role: "Commercial Director",
    education: "University of Kigali",
    description:
      "Former Sales leader at Bboxx Rwanda, Sub Saharan Africa's largest retail solar business. Impact-driven results leader.",
    expertise: ["Sales", "Commercial", "Solar Energy"],
  },
  {
    name: "Olivier Iryamukuru",
    role: "Business Operations Director",
    education: "Abilene Christian University",
    description:
      "Former Investment Strategist and Financial Analyst at BlackRock. Extensive experience in business analytics and finance.",
    expertise: ["Analytics", "Investment", "Operations"],
  },
  {
    name: "Gordon Bradford",
    role: "Group Engineering & Construction Director",
    education: "30+ years experience",
    description:
      "First employee at Kivu Choice. Over 3 decades of construction, maintenance, and project management experience in Africa.",
    expertise: ["Construction", "Engineering", "Project Management"],
  },
  {
    name: "Ronah Nabukeera",
    role: "Hatchery Manager",
    education: "Fisheries and Aquaculture Degree",
    description:
      "10+ years hatchery expertise across Uganda, Kenya, Ghana, and Rwanda. Expert in team development and operational excellence.",
    expertise: ["Hatchery", "Aquaculture", "Team Development"],
  },
]

export default function TeamSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-kivu-green/5 to-kivu-blue/5">
      <div className="container mx-auto px-4">
        {/* Hero Image Section */}
        <div className="mb-16">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl mb-8">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FeedersTeam-1024x683.jpg-cA7vQ4FKAIRI6BVf3tqUKNAcrdBx5s.jpeg"
              alt="Kivu Choice team working together on Lake Kivu operations"
              className="w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-8 text-white">
              <h3 className="text-2xl font-bold mb-2">Our Team in Action</h3>
              <p className="text-lg opacity-90">Working together on Lake Kivu to deliver excellence</p>
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-kivu-green/10 text-kivu-green px-4 py-2 rounded-full text-sm font-body font-medium mb-4">
            <div className="w-2 h-2 bg-kivu-green rounded-full"></div>
            World-Class Leadership
          </div>
          <h2 className="font-heading text-4xl md:text-5xl font-black text-foreground mb-6">
            Meet Our <span className="text-kivu-green">Expert</span> Team
          </h2>
          <p className="font-body text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            From Stanford to Harvard, BlackRock to Victory Farms - our leadership brings decades of experience from the
            world's top institutions and companies to revolutionize African aquaculture.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <Card
              key={index}
              className="group hover:shadow-2xl transition-all duration-300 border-0 bg-background/80 backdrop-blur-sm hover:-translate-y-2"
            >
              <CardContent className="p-8">
                {/* Role Badge */}
                <div className="mb-4">
                  <Badge
                    variant="outline"
                    className="bg-kivu-blue/10 text-kivu-blue border-kivu-blue/20 px-3 py-1 font-body"
                  >
                    {member.role}
                  </Badge>
                </div>

                {/* Name */}
                <h3 className="font-heading text-2xl font-bold text-foreground mb-2 group-hover:text-kivu-green transition-colors">
                  {member.name}
                </h3>

                {/* Education */}
                <p className="font-body text-sm font-semibold text-kivu-green mb-4">{member.education}</p>

                {/* Description */}
                <p className="font-body text-muted-foreground mb-6 leading-relaxed">{member.description}</p>

                {/* Expertise Tags */}
                <div className="flex flex-wrap gap-2">
                  {member.expertise.map((skill, skillIndex) => (
                    <span
                      key={skillIndex}
                      className="px-3 py-1 bg-muted text-muted-foreground rounded-full text-xs font-body font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Row */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="font-heading text-3xl font-black text-kivu-green mb-2">500+</div>
            <div className="font-body text-muted-foreground font-medium">Jobs Created</div>
          </div>
          <div className="text-center">
            <div className="font-heading text-3xl font-black text-kivu-blue mb-2">10+</div>
            <div className="font-body text-muted-foreground font-medium">Team Countries</div>
          </div>
          <div className="text-center">
            <div className="font-heading text-3xl font-black text-kivu-green mb-2">50+</div>
            <div className="font-body text-muted-foreground font-medium">Years Combined Experience</div>
          </div>
          <div className="text-center">
            <div className="font-heading text-3xl font-black text-kivu-blue mb-2">5</div>
            <div className="font-body text-muted-foreground font-medium">Top Universities</div>
          </div>
        </div>
      </div>
    </section>
  )
}
