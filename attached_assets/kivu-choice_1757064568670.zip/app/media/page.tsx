import { Header } from "@/components/header"
import MediaSection from "@/components/media-section"
import { Footer } from "@/components/footer"

export default function MediaPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-20">
        <MediaSection />
      </div>
      <Footer />
    </div>
  )
}
