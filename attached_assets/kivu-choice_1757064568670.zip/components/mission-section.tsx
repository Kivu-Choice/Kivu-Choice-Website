import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Fish, Waves, Users, Leaf, ArrowRight } from "lucide-react"

export function MissionSection() {
  const impacts = [
    {
      icon: Fish,
      title: "Premium Quality",
      description:
        "Delivering the highest quality tilapia through advanced aquaculture techniques and strict quality control.",
      stat: "400MT",
      statLabel: "Monthly Harvest",
    },
    {
      icon: Waves,
      title: "Lake Kivu Excellence",
      description:
        "Utilizing Rwanda's pristine Lake Kivu waters to produce exceptional tilapia with superior taste and texture.",
      stat: "5M+",
      statLabel: "Fingerlings Annually",
    },
    {
      icon: Users,
      title: "Job Creation",
      description:
        "Creating sustainable employment opportunities and supporting local communities through aquaculture.",
      stat: "500+",
      statLabel: "Jobs Created",
    },
    {
      icon: Leaf,
      title: "Sustainable Farming",
      description: "Environmentally responsible aquaculture practices that protect Rwanda's precious water resources.",
      stat: "100%",
      statLabel: "Sustainable",
    },
  ]

  return (
    <section className="py-20 lg:py-32 bg-gradient-to-br from-kivu-green/5 via-background to-kivu-blue/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Mission Statement */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center space-x-2 bg-kivu-blue/10 text-kivu-blue px-4 py-2 rounded-full text-sm font-body font-medium mb-6">
            <Fish className="h-4 w-4" />
            <span>Our Mission</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-foreground mb-8 max-w-4xl mx-auto">
            Leading Rwanda's <span className="text-kivu-blue">Aquaculture Revolution</span> Through
            <span className="text-kivu-green"> Sustainable Excellence</span>
          </h2>
          <p className="font-body text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">
            We are committed to being Africa's fastest growing fish farm, delivering premium tilapia while creating jobs
            and supporting Rwanda's economic growth through sustainable aquaculture.
          </p>

          {/* Mission Pillars */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-background/80 backdrop-blur-sm rounded-lg p-6 border">
              <h3 className="font-heading text-lg font-bold text-foreground mb-2">Quality Excellence</h3>
              <p className="font-body text-sm text-muted-foreground">
                Every fish we produce meets the highest standards of quality, freshness, and taste.
              </p>
            </div>
            <div className="bg-background/80 backdrop-blur-sm rounded-lg p-6 border">
              <h3 className="font-heading text-lg font-bold text-foreground mb-2">Sustainable Operations</h3>
              <p className="font-body text-sm text-muted-foreground">
                Environmentally responsible farming that protects Lake Kivu and supports local communities.
              </p>
            </div>
            <div className="bg-background/80 backdrop-blur-sm rounded-lg p-6 border">
              <h3 className="font-heading text-lg font-bold text-foreground mb-2">Market Leadership</h3>
              <p className="font-body text-sm text-muted-foreground">
                Building Rwanda's largest protein production operation and expanding across East Africa.
              </p>
            </div>
          </div>
        </div>

        {/* Impact Areas */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {impacts.map((impact, index) => (
            <Card
              key={index}
              className="border-0 bg-background/60 backdrop-blur-sm hover:bg-background/80 transition-all duration-300 group"
            >
              <CardContent className="p-6 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-kivu-green/10 group-hover:bg-kivu-green/20 transition-colors mx-auto mb-4">
                  <impact.icon className="h-7 w-7 text-kivu-green" />
                </div>
                <div className="font-heading text-3xl font-black text-foreground mb-1">{impact.stat}</div>
                <div className="font-body text-xs text-kivu-blue font-medium mb-3">{impact.statLabel}</div>
                <h4 className="font-heading text-lg font-bold text-foreground mb-2">{impact.title}</h4>
                <p className="font-body text-sm text-muted-foreground leading-relaxed">{impact.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center bg-background/80 backdrop-blur-sm rounded-2xl p-12 border">
          <h3 className="font-heading text-2xl font-bold text-foreground mb-4">
            Partner with Rwanda's Leading Fish Farm
          </h3>
          <p className="font-body text-muted-foreground mb-8 max-w-2xl mx-auto">
            Whether you're a restaurant seeking premium tilapia, a distributor looking for reliable supply, or an
            investor interested in sustainable aquaculture, join us in building Rwanda's protein future.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="font-body font-semibold bg-kivu-blue hover:bg-kivu-blue/90 text-white group">
              View Our Products
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="font-body font-semibold bg-transparent border-kivu-green text-kivu-green hover:bg-kivu-green hover:text-white"
            >
              Contact Sales Team
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
