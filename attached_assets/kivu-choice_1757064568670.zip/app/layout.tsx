import type React from "react"
import type { Metadata } from "next"
import { Montserrat, Open_Sans } from "next/font/google"
import { CartProvider } from "@/lib/cart-context"
import "./globals.css"

const montserrat = Montserrat({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-montserrat",
  weight: ["400", "600", "700", "900"],
})

const openSans = Open_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-open-sans",
  weight: ["400", "500", "600"],
})

export const metadata: Metadata = {
  title: "Kivu Choice - Fresh Rwandan Tilapia | Africa's Fastest Growing Fish Farm",
  description:
    "Rwanda's largest protein producer delivering premium tilapia from Lake Kivu. Vertically integrated aquaculture operations from hatchery to your table.",
  keywords: "Rwanda tilapia, Lake Kivu fish, aquaculture, fresh fish, protein producer, fish farm",
  authors: [{ name: "Kivu Choice" }],
  creator: "Kivu Choice",
  publisher: "Kivu Choice",
  openGraph: {
    title: "Kivu Choice - Fresh Rwandan Tilapia",
    description: "Rwanda's largest protein producer delivering premium tilapia from Lake Kivu",
    url: "https://kivuchoice.rw",
    siteName: "Kivu Choice",
    images: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Fish-and-text_Horizontal_Color-2048x823-KNTahs43kDdKqRk9a0GPldS7krlaEO.png",
        width: 2048,
        height: 823,
        alt: "Kivu Choice - Fresh Rwandan Tilapia",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Kivu Choice - Fresh Rwandan Tilapia",
    description: "Rwanda's largest protein producer delivering premium tilapia from Lake Kivu",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/KC_Fish-and-text_Horizontal_Color-2048x823-KNTahs43kDdKqRk9a0GPldS7krlaEO.png",
    ],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${montserrat.variable} ${openSans.variable} antialiased`}>
      <head>
        <link rel="canonical" href="https://kivuchoice.rw" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  )
}
