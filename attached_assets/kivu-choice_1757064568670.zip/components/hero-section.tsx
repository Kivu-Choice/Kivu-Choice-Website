import { Button } from "@/components/ui/button"
import { ArrowRight, Fish, Factory, TrendingUp } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-primary/5">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))] dark:bg-grid-slate-700/25 dark:[mask-image:linear-gradient(0deg,rgba(255,255,255,0.1),rgba(255,255,255,0.5))]" />

      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-body font-medium">
              <Fish className="h-4 w-4" />
              <span>Africa's Fastest Growing Fish Farm</span>
            </div>

            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-black text-foreground leading-tight">
              <span className="text-primary">Fresh Rwandan Tilapia</span> from Lake Kivu to Your Table
            </h1>

            <p className="font-body text-lg sm:text-xl text-muted-foreground leading-relaxed max-w-xl">
              Rwanda's largest protein producer with vertically integrated operations including hatchery, cage
              production, and nationwide distribution of premium fresh tilapia.
            </p>

            <div className="flex flex-wrap gap-8">
              <div className="flex items-center space-x-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Factory className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-heading text-2xl font-bold text-foreground">400MT</div>
                  <div className="font-body text-sm text-muted-foreground">Monthly Harvest</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                  <TrendingUp className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <div className="font-heading text-2xl font-bold text-foreground">500+</div>
                  <div className="font-body text-sm text-muted-foreground">Jobs Created</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="font-body font-semibold bg-primary hover:bg-primary/90 text-primary-foreground group"
              >
                Find Our Branches
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button variant="outline" size="lg" className="font-body font-semibold bg-transparent">
                Learn About Our Operations
              </Button>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-08-06%20at%2013.21.51_fb5115b4.jpg-gELb2KI6J4xS0Z5vMakCproBSAkW9a.jpeg"
                alt="Kivu Choice - Fresh Rwandan Tilapia from Lake Kivu"
                className="w-full h-[400px] lg:h-[600px] object-cover"
              />

              <div className="absolute top-6 left-6 bg-background/95 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                <div className="flex items-center space-x-3">
                  <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse" />
                  <span className="font-body text-sm font-medium">Lake Kivu Operations</span>
                </div>
              </div>

              <div className="absolute bottom-6 right-6 bg-background/95 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                <div className="font-body text-sm text-muted-foreground">Daily Harvest</div>
                <div className="font-heading text-2xl font-bold text-primary">13.3MT</div>
                <div className="font-body text-xs text-muted-foreground">Fresh Tilapia</div>
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 h-24 w-24 bg-accent/20 rounded-full blur-xl" />
            <div className="absolute -bottom-8 -left-8 h-32 w-32 bg-primary/20 rounded-full blur-xl" />
          </div>
        </div>
      </div>
    </section>
  )
}
